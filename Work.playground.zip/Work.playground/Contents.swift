import UIKit
import XCTest




// Bai 1 :
 

let array = [2,3,4,8,5,1]
let numK = 1
var total = 0
for i in array {
    for j in array{
        if i + j == numK {
            total += 1
            print("Couple \(total) : Num one is: \(i) and num two is: \(j)")
        }
    }
}

if total == 0 {
    print("No num (X_X)")
}

XCTAssertEqual(total, 0)                           // Hàm test bài 1
 

//  Bai 2 :  Em biết có đề bài yêu cầu viết theo giải thuật Mergesort nhưng em làm cách này e nghĩ có lẽ sẽ nhanh hơn chút ^^
 

let array1 = [10 , 29 , 30]
let array2 = [10 , 50 , 21]
let array3 = [2, 90 , 73]

var  arr = array1 + array2 + array3
arr.sort()
print(arr.sorted())

XCTAssertEqual(arr, [2, 10, 10, 21, 29, 30, 50, 73, 90])        // Hàm test bài 2

//  Bài 3 : Em định đi theo hướng này mà bị mắc trong khoảng số > 100 (em định sẽ dung vòng for bên ngoài) mà cảm thấy chưa hợp lí lắm nên em vẫn để vậy T.T


var arrr = ["0","a","b","c","d","e","f","g","h","i","j","k","l","m","n","o","p","q","r","s","t","u","v","w","x","y","z"]


let i : Int = 17
if i < 11 {
    print(arrr[i])
}else if i < 100 {
    
    let x = i/10
    let y = i%10
    print(arrr[x] , arrr[y])
    XCTAssertEqual(arrr[x] , "a")                     // Hàm test bài 3
    XCTAssertEqual(arrr[y] , "g")                     // Hàm test bài 3
    if i < 27{
        print(arrr[i])
        XCTAssertEqual(arrr[i] , "q")                 // Hàm test bài 3
    }
}



//  Bài 4 : Em thấy hướng thầy chưa được tối ưu lắm ah


func isValid(_ s: String) -> Bool {
    var arrayy = [Character]()
    let charPair: [Character: Character] = [")": "(", "]": "[" ,"}": "{"]
    for char in s {
        if char == "(" || char == "[" || char == "{" {
            arrayy.append(char)
        }
        else if char == "}" || char == "]" || char == ")" {
            if arrayy.isEmpty {
                return false
            }
            let last = arrayy.removeLast()
            if last != charPair[char] {
                return false
            }
        }
    }
    
    return arrayy.isEmpty
}
 print(isValid("{()[]}"))


XCTAssertTrue(true)                   // Hàm test bài 4
